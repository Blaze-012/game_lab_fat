using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawn_management : MonoBehaviour
{
    public GameObject enemyPrefab;
    public Transform[] spawnPoints;
    public float spawnInterval = 2f;

    void Start()
    {
        InvokeRepeating(nameof(SpawnEnemy), 1f, spawnInterval);
    }

    void SpawnEnemy()
    {
        int randomRow = Random.Range(0, spawnPoints.Length);
        Instantiate(enemyPrefab, spawnPoints[randomRow].position, Quaternion.identity);
    }
}
