using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class coinCounter : MonoBehaviour
{
    public static coinCounter instance;
    
    public TMP_Text coinText;
    public TMP_Text winText;
    public int currentCoins = 0;
    public int winningCoins = 5;

    void Awake(){
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {
        coinText.text = "COINS: " + currentCoins.ToString();
        winText.gameObject.SetActive(false);
    }

    public void IncreaseCoins(int value){
        currentCoins += value;
        coinText.text = "COINS: " + currentCoins.ToString();

        if (currentCoins >= winningCoins)
        {
            DisplayWinMessage();
        }
    }

    void DisplayWinMessage()
    {
        winText.gameObject.SetActive(true); // Show the win text
        winText.text = "YOU WON!";
    }

}
