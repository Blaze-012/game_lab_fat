using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class sizeSliderScript : MonoBehaviour
{
    public Slider sizeSlider;
    public GameObject objectToResize;
    private Vector3 originalScale;

    // Start is called before the first frame update
    void Start()
    {
        originalScale = objectToResize.transform.localScale;
        sizeSlider.onValueChanged.AddListener(AdjustSize);
    }

    // Update is called once per frame
    void AdjustSize(float value)
    {
        objectToResize.transform.localScale = originalScale * value;
    }
}
