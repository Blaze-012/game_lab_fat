using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BallScript : MonoBehaviour
{

    public Rigidbody2D rb;
    public GameObject platform;
    public Text resultText;

    private bool isFalling = false;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if (isFalling)
            rb.velocity = new Vector2(rb.velocity.x, -5f); // Ball falls down
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject == platform)
        {
            rb.velocity = new Vector2(0, 5f); // Ball bounces back
        }
    }

    public void DropBall()
    {
        isFalling = true;
    }

    public void ChangeColor()
    {
        GetComponent<SpriteRenderer>().color = new Color(Random.value, Random.value, Random.value);
    }

    public void GameOver()
    {
        if (!isFalling) return;
        resultText.text = "Game Over";
    }
}
